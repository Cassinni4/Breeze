-- moddingp2poptions.lua
local ModdingP2POptions = {}

function ModdingP2POptions:ShowWarning()
    print("Warning: Modding options for P2P are currently unstable.")
end

return ModdingP2POptions
